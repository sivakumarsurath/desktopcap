package onlineCookingPage;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"C:/BDD_749/RecipeClass_186749/Feature/recipe.feature"})
public class RunTester {

}
